from abc import ABC, abstractmethod

class ICelular(ABC):
    @abstractmethod
    def encender(self):
        pass